HW1 - Neural Prosthesis

The report is contained in the file "NeuralProsthesisReport.pdf". 

In can also be readed in a Jupyter Notebook using the "Neural ProsthesisPythonNotebook.ipynb" 
file. However, the code cannot be executed here. 

The full code is contained in the files np1.py and np2.py, for the question 1 and 2 respectively. 

The dependencies to run the code are the NEURON python module (PyNEURON), numpy and scipy, and 
can be installed with pip running "pip install numpy scipy PyNEURON". 


Johan Medrano 